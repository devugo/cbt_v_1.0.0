<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/pages/levels.html.twig */
class __TwigTemplate_fccee90ebd3ac0f76be45948b497cb1ab82d0ca7b48429bd514e0302a163af3c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/pages/levels.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/pages/levels.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "admin/pages/levels.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Devugo CBT - Levels";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "

    <div class=\"page-wrapper\">
        <!-- MENU SIDEBAR-->
        <aside class=\"menu-sidebar2\">
            <div class=\"logo\">
                <a href=\"/admin/\">
                    <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/site_images/devugo_logo.jpg"), "html", null, true);
        echo "\" width=\"40\" alt=\"Site Logo\" /> <span style=\"color: white; font-size: 25px;\">DEVUGO CBT</span>
                </a>
            </div>
            <div class=\"menu-sidebar2__content js-scrollbar1\">
                <div class=\"account2\">
                    <div class=\"image img-cir img-120\">
                        <img style=\"width: 130px; height: 130px\" src=\"/uploads/user_avatars/";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 19, $this->source); })()), "user", [], "any", false, false, false, 19), "photo", [], "any", false, false, false, 19), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 19, $this->source); })()), "user", [], "any", false, false, false, 19), "username", [], "any", false, false, false, 19), "html", null, true);
        echo " photo\" />
                    </div>
                    <h4 class=\"name\">";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 21, $this->source); })()), "user", [], "any", false, false, false, 21), "username", [], "any", false, false, false, 21), "html", null, true);
        echo "</h4>
                    <a href=\"/logout\">Sign out</a>
                </div>
                <nav class=\"navbar-sidebar2\">
                    <ul class=\"list-unstyled navbar__list\">
                        <li>
                            <a href=\"";
        // line 27
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_dashboard");
        echo "\">
                                <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                            </a>
                        </li>
                        <li>
                            <a href=\"";
        // line 32
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_users");
        echo "\">
                                <i class=\"fas fa-user\"></i>Users</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_groups");
        echo "\">
                                <i class=\"fas fa-users\"></i>User Groups</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 40
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_subjects");
        echo "\">
                                <i class=\"fas fa-indent\"></i>Subjects</a>
                        </li>
                        <li class=\"active has-sub\">
                            <a href=\"";
        // line 44
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_levels");
        echo "\">
                                <i class=\"fas fa-align-right\"></i>Levels</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_questions");
        echo "\">
                                <i class=\"fas fa-list-alt\"></i>Questions</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 52
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_exams");
        echo "\">
                                <i class=\"fas fa-book\"></i>Exam</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 56
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_account_types");
        echo "\">
                                <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 60
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_notifications");
        echo "\">
                                <i class=\"fas fa-bell\"></i>Notifications</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 64
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_results");
        echo "\">
                                <i class=\"fas fa-trophy\"></i>Results</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class=\"page-container2\">
            <!-- HEADER DESKTOP-->
            <header class=\"header-desktop2\">
                <div class=\"section__content section__content--p30\">
                    <div class=\"container-fluid\">
                        <div class=\"header-wrap2\">
                            <div class=\"logo d-block d-lg-none\">
                                <a href=\"/admin/\">
                                    <img src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/site_images/devugo_logo.jpg"), "html", null, true);
        echo "\" width=\"40\" alt=\"Site Logo\" />
                                </a>
                            </div>
                            <div class=\"header-button2\">
                                <div class=\"header-button-item mr-0 js-sidebar-btn\">
                                    <i class=\"zmdi zmdi-menu\"></i>
                                </div>
                                <div class=\"setting-menu js-right-sidebar d-none d-lg-block\">
                                    <div class=\"account-dropdown__body\">
                                        <div class=\"account-dropdown__item\">
                                            <a href=\"";
        // line 92
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_profile");
        echo "\">
                                            <i class=\"fas fa-user\"></i>Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <aside class=\"menu-sidebar2 js-right-sidebar d-block d-lg-none\">
                <div class=\"logo\">
                    <a href=\"/admin/\">
                        <img src=\"";
        // line 105
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/site_images/devugo_logo.jpg"), "html", null, true);
        echo "\" width=\"40\" alt=\"Site Logo\" />
                    </a>
                </div>
                <div class=\"menu-sidebar2__content js-scrollbar2\">
                    <div class=\"account2\">
                        <div class=\"image img-cir img-120\">
                            <img src=\"/uploads/user_avatars/";
        // line 111
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 111, $this->source); })()), "user", [], "any", false, false, false, 111), "photo", [], "any", false, false, false, 111), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 111, $this->source); })()), "user", [], "any", false, false, false, 111), "username", [], "any", false, false, false, 111), "html", null, true);
        echo " photo\" />
                        </div>
                        <h4 class=\"name\">";
        // line 113
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 113, $this->source); })()), "user", [], "any", false, false, false, 113), "lastname", [], "any", false, false, false, 113), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 113, $this->source); })()), "user", [], "any", false, false, false, 113), "firstname", [], "any", false, false, false, 113), "html", null, true);
        echo "</h4>
                        <a href=\"/logout\">Sign out</a>
                    </div>
                    <nav class=\"navbar-sidebar2\">
                        <ul class=\"list-unstyled navbar__list\">
                            <li>
                                <a href=\"";
        // line 119
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_dashboard");
        echo "\">
                                    <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                                </a>
                            </li>
                            <li>
                                <a href=\"";
        // line 124
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_users");
        echo "\">
                                    <i class=\"fas fa-user\"></i>Users</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 128
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_groups");
        echo "\">
                                    <i class=\"fas fa-users\"></i>User Groups</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 132
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_subjects");
        echo "\">
                                    <i class=\"fas fa-indent\"></i>Subjects</a>
                            </li>
                            <li class=\"active has-sub\">
                                <a href=\"";
        // line 136
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_levels");
        echo "\">
                                    <i class=\"fas fa-align-right\"></i>Levels</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 140
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_users");
        echo "\">
                                    <i class=\"fas fa-list-alt\"></i>Questions</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 144
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_exams");
        echo "\">
                                    <i class=\"fas fa-book\"></i>Exam</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 148
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_account_types");
        echo "\">
                                    <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 152
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_notifications");
        echo "\">
                                    <i class=\"fas fa-bell\"></i>Notifications</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 156
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_results");
        echo "\">
                                    <i class=\"fas fa-trophy\"></i>Results</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 160
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_profile");
        echo "\">
                                    <i class=\"fas fa-user\"></i>Profile</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </aside>
            <!-- END HEADER DESKTOP-->

            <div id=\"admin-levels\"></div><br /><br /><br /><br /><br />

            ";
        // line 171
        $this->loadTemplate("admin/layout/footer.html.twig", "admin/pages/levels.html.twig", 171)->display($context);
        // line 172
        echo "
           
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "admin/pages/levels.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  352 => 172,  350 => 171,  336 => 160,  329 => 156,  322 => 152,  315 => 148,  308 => 144,  301 => 140,  294 => 136,  287 => 132,  280 => 128,  273 => 124,  265 => 119,  254 => 113,  247 => 111,  238 => 105,  222 => 92,  209 => 82,  188 => 64,  181 => 60,  174 => 56,  167 => 52,  160 => 48,  153 => 44,  146 => 40,  139 => 36,  132 => 32,  124 => 27,  115 => 21,  108 => 19,  99 => 13,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Devugo CBT - Levels{% endblock %}

{% block body %}
    {{ parent() }}

    <div class=\"page-wrapper\">
        <!-- MENU SIDEBAR-->
        <aside class=\"menu-sidebar2\">
            <div class=\"logo\">
                <a href=\"/admin/\">
                    <img src=\"{{ asset('uploads/site_images/devugo_logo.jpg') }}\" width=\"40\" alt=\"Site Logo\" /> <span style=\"color: white; font-size: 25px;\">DEVUGO CBT</span>
                </a>
            </div>
            <div class=\"menu-sidebar2__content js-scrollbar1\">
                <div class=\"account2\">
                    <div class=\"image img-cir img-120\">
                        <img style=\"width: 130px; height: 130px\" src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }} photo\" />
                    </div>
                    <h4 class=\"name\">{{app.user.username}}</h4>
                    <a href=\"/logout\">Sign out</a>
                </div>
                <nav class=\"navbar-sidebar2\">
                    <ul class=\"list-unstyled navbar__list\">
                        <li>
                            <a href=\"{{ path('admin_dashboard') }}\">
                                <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                            </a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_users') }}\">
                                <i class=\"fas fa-user\"></i>Users</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_user_groups') }}\">
                                <i class=\"fas fa-users\"></i>User Groups</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_subjects') }}\">
                                <i class=\"fas fa-indent\"></i>Subjects</a>
                        </li>
                        <li class=\"active has-sub\">
                            <a href=\"{{ path('admin_levels') }}\">
                                <i class=\"fas fa-align-right\"></i>Levels</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_questions') }}\">
                                <i class=\"fas fa-list-alt\"></i>Questions</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_exams') }}\">
                                <i class=\"fas fa-book\"></i>Exam</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_account_types') }}\">
                                <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_notifications') }}\">
                                <i class=\"fas fa-bell\"></i>Notifications</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_results') }}\">
                                <i class=\"fas fa-trophy\"></i>Results</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class=\"page-container2\">
            <!-- HEADER DESKTOP-->
            <header class=\"header-desktop2\">
                <div class=\"section__content section__content--p30\">
                    <div class=\"container-fluid\">
                        <div class=\"header-wrap2\">
                            <div class=\"logo d-block d-lg-none\">
                                <a href=\"/admin/\">
                                    <img src=\"{{ asset('uploads/site_images/devugo_logo.jpg') }}\" width=\"40\" alt=\"Site Logo\" />
                                </a>
                            </div>
                            <div class=\"header-button2\">
                                <div class=\"header-button-item mr-0 js-sidebar-btn\">
                                    <i class=\"zmdi zmdi-menu\"></i>
                                </div>
                                <div class=\"setting-menu js-right-sidebar d-none d-lg-block\">
                                    <div class=\"account-dropdown__body\">
                                        <div class=\"account-dropdown__item\">
                                            <a href=\"{{ path('admin_profile') }}\">
                                            <i class=\"fas fa-user\"></i>Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <aside class=\"menu-sidebar2 js-right-sidebar d-block d-lg-none\">
                <div class=\"logo\">
                    <a href=\"/admin/\">
                        <img src=\"{{ asset('uploads/site_images/devugo_logo.jpg') }}\" width=\"40\" alt=\"Site Logo\" />
                    </a>
                </div>
                <div class=\"menu-sidebar2__content js-scrollbar2\">
                    <div class=\"account2\">
                        <div class=\"image img-cir img-120\">
                            <img src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }} photo\" />
                        </div>
                        <h4 class=\"name\">{{ app.user.lastname }} {{ app.user.firstname }}</h4>
                        <a href=\"/logout\">Sign out</a>
                    </div>
                    <nav class=\"navbar-sidebar2\">
                        <ul class=\"list-unstyled navbar__list\">
                            <li>
                                <a href=\"{{ path('admin_dashboard') }}\">
                                    <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_users') }}\">
                                    <i class=\"fas fa-user\"></i>Users</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_user_groups') }}\">
                                    <i class=\"fas fa-users\"></i>User Groups</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_subjects') }}\">
                                    <i class=\"fas fa-indent\"></i>Subjects</a>
                            </li>
                            <li class=\"active has-sub\">
                                <a href=\"{{ path('admin_levels') }}\">
                                    <i class=\"fas fa-align-right\"></i>Levels</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_users') }}\">
                                    <i class=\"fas fa-list-alt\"></i>Questions</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_exams') }}\">
                                    <i class=\"fas fa-book\"></i>Exam</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_account_types') }}\">
                                    <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_notifications') }}\">
                                    <i class=\"fas fa-bell\"></i>Notifications</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_results') }}\">
                                    <i class=\"fas fa-trophy\"></i>Results</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_profile') }}\">
                                    <i class=\"fas fa-user\"></i>Profile</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </aside>
            <!-- END HEADER DESKTOP-->

            <div id=\"admin-levels\"></div><br /><br /><br /><br /><br />

            {% include 'admin/layout/footer.html.twig' %}

           
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
{% endblock %}
", "admin/pages/levels.html.twig", "C:\\PROJECTS\\personnal\\devugo_cbt_v_1.0.0\\templates\\admin\\pages\\levels.html.twig");
    }
}
