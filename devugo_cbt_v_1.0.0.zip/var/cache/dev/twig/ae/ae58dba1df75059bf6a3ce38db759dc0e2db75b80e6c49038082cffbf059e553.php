<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/layout/mobile-header.html.twig */
class __TwigTemplate_f3946d21b5adb31839cc98c92775f0f9642a1631f3d31ee89c7b4b002c4031e2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/layout/mobile-header.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/layout/mobile-header.html.twig"));

        // line 1
        echo "<header class=\"header-mobile header-mobile-2 d-block d-lg-none\">
            <div class=\"header-mobile__bar\">
                <div class=\"container-fluid\">
                    <div class=\"header-mobile-inner\">
                        <a class=\"logo\" href=\"/user/\">
                            <img src=\"/uploads/site_images/devugo_logo.jpg\" width=\"40\" alt=\"Site logo\" />
                        </a>
                        <button class=\"hamburger hamburger--slider\" type=\"button\">
                            <span class=\"hamburger-box\">
                                <span class=\"hamburger-inner\"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class=\"navbar-mobile\">
                <div class=\"container-fluid\">
                    <ul class=\"navbar-mobile__list list-unstyled\">
                        <li>
                            <a href=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_exams");
        echo "\">
                                <i class=\"fas fa-book\"></i>Exams</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 24
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_results");
        echo "\">
                                <i class=\"fas fa-trophy\"></i>Results</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class=\"sub-header-mobile-2 d-block d-lg-none\">
            <div class=\"header__tool\">
                <div class=\"header-button-item has-noti js-item-menu\">
                    <i class=\"zmdi zmdi-notifications\"></i>
                    <div class=\"notifi-dropdown notifi-dropdown--no-bor js-dropdown\">
                        <div class=\"notifi__title\">
                            <p>You have ";
        // line 37
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["no_of_unread"]) || array_key_exists("no_of_unread", $context) ? $context["no_of_unread"] : (function () { throw new RuntimeError('Variable "no_of_unread" does not exist.', 37, $this->source); })())), "html", null, true);
        echo " new Notifications</p>
                        </div>
                        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notifications"]) || array_key_exists("notifications", $context) ? $context["notifications"] : (function () { throw new RuntimeError('Variable "notifications" does not exist.', 39, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["noti"]) {
            // line 40
            echo "                            <div class=\"notifi__item\">
                                <div class=\"bg-c2 img-cir img-40\">
                                    <i class=\"zmdi zmdi-account-box\"></i>
                                </div>
                                <div class=\"content\">
                                    <p>";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["noti"], "title", [], "any", false, false, false, 45), "html", null, true);
            echo "</p>
                                    <span class=\"date\">";
            // line 46
            echo $this->extensions['Knp\Bundle\TimeBundle\Twig\Extension\TimeExtension']->diff(twig_get_attribute($this->env, $this->source, $context["noti"], "createdAt", [], "any", false, false, false, 46));
            echo "</span>
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['noti'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                        <div class=\"notifi__footer\">
                            <a href=\"";
        // line 51
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_notifications");
        echo "\">All notifications</a>
                        </div>
                    </div>
                </div>
                <div class=\"account-wrap\">
                    <div class=\"account-item account-item--style2 clearfix js-item-menu\">
                        <div class=\"image\">
                            <img src=\"/uploads/user_avatars/";
        // line 58
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 58, $this->source); })()), "user", [], "any", false, false, false, 58), "photo", [], "any", false, false, false, 58), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 58, $this->source); })()), "user", [], "any", false, false, false, 58), "username", [], "any", false, false, false, 58), "html", null, true);
        echo "\" />
                        </div>
                        <div class=\"content\">
                            <a class=\"js-acc-btn\" href=\"#\">";
        // line 61
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 61, $this->source); })()), "user", [], "any", false, false, false, 61), "username", [], "any", false, false, false, 61), "html", null, true);
        echo "</a>
                        </div>
                        <div class=\"account-dropdown js-dropdown\">
                            <div class=\"info clearfix\">
                                <div class=\"image\">
                                    <a href=\"#\">
                                        <img src=\"/uploads/user_avatars/";
        // line 67
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 67, $this->source); })()), "user", [], "any", false, false, false, 67), "photo", [], "any", false, false, false, 67), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 67, $this->source); })()), "user", [], "any", false, false, false, 67), "username", [], "any", false, false, false, 67), "html", null, true);
        echo "\" />
                                    </a>
                                </div>
                                <div class=\"content\">
                                    <h5 class=\"name\">
                                        <a href=\"#\">";
        // line 72
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 72, $this->source); })()), "user", [], "any", false, false, false, 72), "lastname", [], "any", false, false, false, 72), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 72, $this->source); })()), "user", [], "any", false, false, false, 72), "firstname", [], "any", false, false, false, 72), "html", null, true);
        echo "</a>
                                    </h5>
                                    <span class=\"email\">";
        // line 74
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 74, $this->source); })()), "user", [], "any", false, false, false, 74), "email", [], "any", false, false, false, 74), "html", null, true);
        echo "</span>
                                </div>
                            </div>
                            <div class=\"account-dropdown__body\">
                                <div class=\"account-dropdown__item\">
                                    <a href=\"#\">
                                        <i class=\"zmdi zmdi-account\"></i>Account</a>
                                </div>
                            </div>
                            <div class=\"account-dropdown__footer\">
                                <a href=\"/logout\">
                                    <i class=\"zmdi zmdi-power\"></i>Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/layout/mobile-header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 74,  157 => 72,  147 => 67,  138 => 61,  130 => 58,  120 => 51,  117 => 50,  107 => 46,  103 => 45,  96 => 40,  92 => 39,  87 => 37,  71 => 24,  64 => 20,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header class=\"header-mobile header-mobile-2 d-block d-lg-none\">
            <div class=\"header-mobile__bar\">
                <div class=\"container-fluid\">
                    <div class=\"header-mobile-inner\">
                        <a class=\"logo\" href=\"/user/\">
                            <img src=\"/uploads/site_images/devugo_logo.jpg\" width=\"40\" alt=\"Site logo\" />
                        </a>
                        <button class=\"hamburger hamburger--slider\" type=\"button\">
                            <span class=\"hamburger-box\">
                                <span class=\"hamburger-inner\"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class=\"navbar-mobile\">
                <div class=\"container-fluid\">
                    <ul class=\"navbar-mobile__list list-unstyled\">
                        <li>
                            <a href=\"{{ path('user_exams') }}\">
                                <i class=\"fas fa-book\"></i>Exams</a>
                        </li>
                        <li>
                            <a href=\"{{ path('user_results') }}\">
                                <i class=\"fas fa-trophy\"></i>Results</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <div class=\"sub-header-mobile-2 d-block d-lg-none\">
            <div class=\"header__tool\">
                <div class=\"header-button-item has-noti js-item-menu\">
                    <i class=\"zmdi zmdi-notifications\"></i>
                    <div class=\"notifi-dropdown notifi-dropdown--no-bor js-dropdown\">
                        <div class=\"notifi__title\">
                            <p>You have {{ no_of_unread|length }} new Notifications</p>
                        </div>
                        {% for noti in notifications %}
                            <div class=\"notifi__item\">
                                <div class=\"bg-c2 img-cir img-40\">
                                    <i class=\"zmdi zmdi-account-box\"></i>
                                </div>
                                <div class=\"content\">
                                    <p>{{ noti.title }}</p>
                                    <span class=\"date\">{{ noti.createdAt|ago }}</span>
                                </div>
                            </div>
                        {% endfor %}
                        <div class=\"notifi__footer\">
                            <a href=\"{{ path('user_notifications') }}\">All notifications</a>
                        </div>
                    </div>
                </div>
                <div class=\"account-wrap\">
                    <div class=\"account-item account-item--style2 clearfix js-item-menu\">
                        <div class=\"image\">
                            <img src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }}\" />
                        </div>
                        <div class=\"content\">
                            <a class=\"js-acc-btn\" href=\"#\">{{ app.user.username }}</a>
                        </div>
                        <div class=\"account-dropdown js-dropdown\">
                            <div class=\"info clearfix\">
                                <div class=\"image\">
                                    <a href=\"#\">
                                        <img src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }}\" />
                                    </a>
                                </div>
                                <div class=\"content\">
                                    <h5 class=\"name\">
                                        <a href=\"#\">{{ app.user.lastname }} {{ app.user.firstname }}</a>
                                    </h5>
                                    <span class=\"email\">{{ app.user.email }}</span>
                                </div>
                            </div>
                            <div class=\"account-dropdown__body\">
                                <div class=\"account-dropdown__item\">
                                    <a href=\"#\">
                                        <i class=\"zmdi zmdi-account\"></i>Account</a>
                                </div>
                            </div>
                            <div class=\"account-dropdown__footer\">
                                <a href=\"/logout\">
                                    <i class=\"zmdi zmdi-power\"></i>Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>", "user/layout/mobile-header.html.twig", "C:\\PROJECTS\\personnal\\devugo_cbt_v_1.0.0\\templates\\user\\layout\\mobile-header.html.twig");
    }
}
