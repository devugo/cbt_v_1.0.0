<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/layout/breadcrumb.html.twig */
class __TwigTemplate_b0625571a1786d87d8c36df99e8c2ae0efa7d79e0be08d692ccae0d9c1a3e9ad extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/layout/breadcrumb.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/layout/breadcrumb.html.twig"));

        // line 1
        echo "<section class=\"au-breadcrumb2\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"au-breadcrumb-content\">
                    <div class=\"au-breadcrumb-left\">
                        <span class=\"au-breadcrumb-span\">You are here:</span>
                        <ul class=\"list-unstyled list-inline au-breadcrumb__list\">
                            <li class=\"list-inline-item active\">
                                <a href=\"";
        // line 10
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_exams");
        echo "\">Home</a>
                            </li>
                            <li class=\"list-inline-item seprate\">
                                <span>/</span>
                            </li>
                            <li class=\"list-inline-item\">";
        // line 15
        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 15, $this->source); })()), "html", null, true);
        echo "</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/layout/breadcrumb.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 15,  54 => 10,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<section class=\"au-breadcrumb2\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"au-breadcrumb-content\">
                    <div class=\"au-breadcrumb-left\">
                        <span class=\"au-breadcrumb-span\">You are here:</span>
                        <ul class=\"list-unstyled list-inline au-breadcrumb__list\">
                            <li class=\"list-inline-item active\">
                                <a href=\"{{ path('user_exams') }}\">Home</a>
                            </li>
                            <li class=\"list-inline-item seprate\">
                                <span>/</span>
                            </li>
                            <li class=\"list-inline-item\">{{ title }}</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>", "user/layout/breadcrumb.html.twig", "C:\\PROJECTS\\personnal\\devugo_cbt_v_1.0.0\\templates\\user\\layout\\breadcrumb.html.twig");
    }
}
