<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/pages/users.html.twig */
class __TwigTemplate_e4161afdfafa8574453755bd2153b2098bedb35fae039d0965387929f0e4fc50 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/pages/users.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/pages/users.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "admin/pages/users.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Devugo CBT - Users";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "

    <div class=\"page-wrapper\">
        <!-- MENU SIDEBAR-->
        <aside class=\"menu-sidebar2\">
            <div class=\"logo\">
                <a href=\"/admin/\">
                    <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/site_images/devugo_logo.jpg"), "html", null, true);
        echo "\" width=\"40\" alt=\"Site Logo\" /> <span style=\"color: white; font-size: 25px;\">DEVUGO CBT</span>
                </a>
            </div>
            <div class=\"menu-sidebar2__content js-scrollbar1\">
                <div class=\"account2\">
                    <div class=\"image img-cir img-120\">
                        <img style=\"width: 130px; height: 130px\" src=\"/uploads/user_avatars/";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 19, $this->source); })()), "user", [], "any", false, false, false, 19), "photo", [], "any", false, false, false, 19), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 19, $this->source); })()), "user", [], "any", false, false, false, 19), "username", [], "any", false, false, false, 19), "html", null, true);
        echo " photo\" />
                    </div>
                    <h4 class=\"name\">";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 21, $this->source); })()), "user", [], "any", false, false, false, 21), "username", [], "any", false, false, false, 21), "html", null, true);
        echo "</h4>
                    <a href=\"/logout\">Sign out</a>
                </div>
                <nav class=\"navbar-sidebar2\">
                    <ul class=\"list-unstyled navbar__list\">
                        <li>
                            <a href=\"";
        // line 27
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_dashboard");
        echo "\">
                                <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                            </a>
                        </li>
                        <li class=\"active has-sub\">
                            <a href=\"";
        // line 32
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_users");
        echo "\">
                                <i class=\"fas fa-user\"></i>Users</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_groups");
        echo "\">
                                <i class=\"fas fa-users\"></i>User Groups</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 40
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_subjects");
        echo "\">
                                <i class=\"fas fa-indent\"></i>Subjects</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 44
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_levels");
        echo "\">
                                <i class=\"fas fa-align-right\"></i>Levels</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_questions");
        echo "\">
                                <i class=\"fas fa-list-alt\"></i>Questions</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 52
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_exams");
        echo "\">
                                <i class=\"fas fa-book\"></i>Exams</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 56
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_account_types");
        echo "\">
                                <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 60
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_notifications");
        echo "\">
                                <i class=\"fas fa-bell\"></i>Notifications</a>
                        </li>
                        <li>
                            <a href=\"";
        // line 64
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_results");
        echo "\">
                                <i class=\"fas fa-trophy\"></i>Results</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class=\"page-container2\">
            <!-- HEADER DESKTOP-->
            <header class=\"header-desktop2\">
                <div class=\"section__content section__content--p30\">
                    <div class=\"container-fluid\">
                        <div class=\"header-wrap2\">
                            <div class=\"logo d-block d-lg-none\">
                                <a href=\"/admin/\">
                                    <img src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/site_images/devugo_logo.jpg"), "html", null, true);
        echo "\" width=\"40\" alt=\"Site Logo\" />
                                </a>
                            </div>
                            <div class=\"header-button2\">
                                <div class=\"header-button-item js-item-menu\">
                                    <i class=\"zmdi zmdi-search\"></i>
                                    <div class=\"search-dropdown js-dropdown\">
                                        <form action=\"\">
                                            <input class=\"au-input au-input--full au-input--h65\" type=\"text\" placeholder=\"Search for datas &amp; reports...\" />
                                            <span class=\"search-dropdown__icon\">
                                                <i class=\"zmdi zmdi-search\"></i>
                                            </span>
                                        </form>
                                    </div>
                                </div>
                                <div class=\"header-button-item mr-0 js-sidebar-btn\">
                                    <i class=\"zmdi zmdi-menu\"></i>
                                </div>
                                <div class=\"setting-menu js-right-sidebar d-none d-lg-block\">
                                    <div class=\"account-dropdown__body\">
                                        <div class=\"account-dropdown__item\">
                                            <a href=\"";
        // line 103
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_profile");
        echo "\">
                                            <i class=\"fas fa-user\"></i>Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <aside class=\"menu-sidebar2 js-right-sidebar d-block d-lg-none\">
                <div class=\"logo\">
                    <a href=\"/admin/\">
                        <img src=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/site_images/devugo_logo.jpg"), "html", null, true);
        echo "\" width=\"40\" alt=\"Site Logo\" />
                    </a>
                </div>
                <div class=\"menu-sidebar2__content js-scrollbar2\">
                    <div class=\"account2\">
                        <div class=\"image img-cir img-120\">
                            <img src=\"/uploads/user_avatars/";
        // line 122
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 122, $this->source); })()), "user", [], "any", false, false, false, 122), "photo", [], "any", false, false, false, 122), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 122, $this->source); })()), "user", [], "any", false, false, false, 122), "username", [], "any", false, false, false, 122), "html", null, true);
        echo " photo\" />
                        </div>
                        <h4 class=\"name\">";
        // line 124
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 124, $this->source); })()), "user", [], "any", false, false, false, 124), "lastname", [], "any", false, false, false, 124), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 124, $this->source); })()), "user", [], "any", false, false, false, 124), "firstname", [], "any", false, false, false, 124), "html", null, true);
        echo "</h4>
                        <a href=\"/logout\">Sign out</a>
                    </div>
                    <nav class=\"navbar-sidebar2\">
                        <ul class=\"list-unstyled navbar__list\">
                            <li>
                                <a href=\"";
        // line 130
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_dashboard");
        echo "\">
                                    <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                                </a>
                            </li>
                            <li class=\"active has-sub\">
                                <a href=\"";
        // line 135
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_users");
        echo "\">
                                    <i class=\"fas fa-user\"></i>Users</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 139
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_groups");
        echo "\">
                                    <i class=\"fas fa-users\"></i>User Groups</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 143
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_subjects");
        echo "\">
                                    <i class=\"fas fa-indent\"></i>Subjects</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 147
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_levels");
        echo "\">
                                    <i class=\"fas fa-align-right\"></i>Levels</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 151
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_users");
        echo "\">
                                    <i class=\"fas fa-list-alt\"></i>Questions</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 155
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_exams");
        echo "\">
                                    <i class=\"fas fa-book\"></i>Exams</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 159
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_account_types");
        echo "\">
                                    <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 163
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_notifications");
        echo "\">
                                    <i class=\"fas fa-bell\"></i>Notifications</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 167
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_results");
        echo "\">
                                    <i class=\"fas fa-trophy\"></i>Results</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 171
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_profile");
        echo "\">
                                    <i class=\"fas fa-user\"></i>Profile</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </aside>
            <!-- END HEADER DESKTOP-->

            <div id=\"admin-users\"></div><br /><br /><br /><br /><br />

            ";
        // line 182
        $this->loadTemplate("admin/layout/footer.html.twig", "admin/pages/users.html.twig", 182)->display($context);
        // line 183
        echo "
           
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "admin/pages/users.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  363 => 183,  361 => 182,  347 => 171,  340 => 167,  333 => 163,  326 => 159,  319 => 155,  312 => 151,  305 => 147,  298 => 143,  291 => 139,  284 => 135,  276 => 130,  265 => 124,  258 => 122,  249 => 116,  233 => 103,  209 => 82,  188 => 64,  181 => 60,  174 => 56,  167 => 52,  160 => 48,  153 => 44,  146 => 40,  139 => 36,  132 => 32,  124 => 27,  115 => 21,  108 => 19,  99 => 13,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Devugo CBT - Users{% endblock %}

{% block body %}
    {{ parent() }}

    <div class=\"page-wrapper\">
        <!-- MENU SIDEBAR-->
        <aside class=\"menu-sidebar2\">
            <div class=\"logo\">
                <a href=\"/admin/\">
                    <img src=\"{{ asset('uploads/site_images/devugo_logo.jpg') }}\" width=\"40\" alt=\"Site Logo\" /> <span style=\"color: white; font-size: 25px;\">DEVUGO CBT</span>
                </a>
            </div>
            <div class=\"menu-sidebar2__content js-scrollbar1\">
                <div class=\"account2\">
                    <div class=\"image img-cir img-120\">
                        <img style=\"width: 130px; height: 130px\" src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }} photo\" />
                    </div>
                    <h4 class=\"name\">{{app.user.username}}</h4>
                    <a href=\"/logout\">Sign out</a>
                </div>
                <nav class=\"navbar-sidebar2\">
                    <ul class=\"list-unstyled navbar__list\">
                        <li>
                            <a href=\"{{ path('admin_dashboard') }}\">
                                <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                            </a>
                        </li>
                        <li class=\"active has-sub\">
                            <a href=\"{{ path('admin_users') }}\">
                                <i class=\"fas fa-user\"></i>Users</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_user_groups') }}\">
                                <i class=\"fas fa-users\"></i>User Groups</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_subjects') }}\">
                                <i class=\"fas fa-indent\"></i>Subjects</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_levels') }}\">
                                <i class=\"fas fa-align-right\"></i>Levels</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_questions') }}\">
                                <i class=\"fas fa-list-alt\"></i>Questions</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_exams') }}\">
                                <i class=\"fas fa-book\"></i>Exams</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_account_types') }}\">
                                <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_notifications') }}\">
                                <i class=\"fas fa-bell\"></i>Notifications</a>
                        </li>
                        <li>
                            <a href=\"{{ path('admin_results') }}\">
                                <i class=\"fas fa-trophy\"></i>Results</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class=\"page-container2\">
            <!-- HEADER DESKTOP-->
            <header class=\"header-desktop2\">
                <div class=\"section__content section__content--p30\">
                    <div class=\"container-fluid\">
                        <div class=\"header-wrap2\">
                            <div class=\"logo d-block d-lg-none\">
                                <a href=\"/admin/\">
                                    <img src=\"{{ asset('uploads/site_images/devugo_logo.jpg') }}\" width=\"40\" alt=\"Site Logo\" />
                                </a>
                            </div>
                            <div class=\"header-button2\">
                                <div class=\"header-button-item js-item-menu\">
                                    <i class=\"zmdi zmdi-search\"></i>
                                    <div class=\"search-dropdown js-dropdown\">
                                        <form action=\"\">
                                            <input class=\"au-input au-input--full au-input--h65\" type=\"text\" placeholder=\"Search for datas &amp; reports...\" />
                                            <span class=\"search-dropdown__icon\">
                                                <i class=\"zmdi zmdi-search\"></i>
                                            </span>
                                        </form>
                                    </div>
                                </div>
                                <div class=\"header-button-item mr-0 js-sidebar-btn\">
                                    <i class=\"zmdi zmdi-menu\"></i>
                                </div>
                                <div class=\"setting-menu js-right-sidebar d-none d-lg-block\">
                                    <div class=\"account-dropdown__body\">
                                        <div class=\"account-dropdown__item\">
                                            <a href=\"{{ path('admin_profile') }}\">
                                            <i class=\"fas fa-user\"></i>Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <aside class=\"menu-sidebar2 js-right-sidebar d-block d-lg-none\">
                <div class=\"logo\">
                    <a href=\"/admin/\">
                        <img src=\"{{ asset('uploads/site_images/devugo_logo.jpg') }}\" width=\"40\" alt=\"Site Logo\" />
                    </a>
                </div>
                <div class=\"menu-sidebar2__content js-scrollbar2\">
                    <div class=\"account2\">
                        <div class=\"image img-cir img-120\">
                            <img src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }} photo\" />
                        </div>
                        <h4 class=\"name\">{{ app.user.lastname }} {{ app.user.firstname }}</h4>
                        <a href=\"/logout\">Sign out</a>
                    </div>
                    <nav class=\"navbar-sidebar2\">
                        <ul class=\"list-unstyled navbar__list\">
                            <li>
                                <a href=\"{{ path('admin_dashboard') }}\">
                                    <i class=\"fas fa-tachometer-alt\"></i>Dashboard
                                </a>
                            </li>
                            <li class=\"active has-sub\">
                                <a href=\"{{ path('admin_users') }}\">
                                    <i class=\"fas fa-user\"></i>Users</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_user_groups') }}\">
                                    <i class=\"fas fa-users\"></i>User Groups</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_subjects') }}\">
                                    <i class=\"fas fa-indent\"></i>Subjects</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_levels') }}\">
                                    <i class=\"fas fa-align-right\"></i>Levels</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_users') }}\">
                                    <i class=\"fas fa-list-alt\"></i>Questions</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_exams') }}\">
                                    <i class=\"fas fa-book\"></i>Exams</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_account_types') }}\">
                                    <i class=\"fas fa-thumb-tack\"></i>Account Types</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_notifications') }}\">
                                    <i class=\"fas fa-bell\"></i>Notifications</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_results') }}\">
                                    <i class=\"fas fa-trophy\"></i>Results</a>
                            </li>
                            <li>
                                <a href=\"{{ path('admin_profile') }}\">
                                    <i class=\"fas fa-user\"></i>Profile</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </aside>
            <!-- END HEADER DESKTOP-->

            <div id=\"admin-users\"></div><br /><br /><br /><br /><br />

            {% include 'admin/layout/footer.html.twig' %}

           
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
{% endblock %}
", "admin/pages/users.html.twig", "C:\\PROJECTS\\personnal\\devugo_cbt_v_1.0.0\\templates\\admin\\pages\\users.html.twig");
    }
}
