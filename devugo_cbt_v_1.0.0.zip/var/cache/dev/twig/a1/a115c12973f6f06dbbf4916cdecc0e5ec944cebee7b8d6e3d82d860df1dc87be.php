<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/layout/desktop-header.html.twig */
class __TwigTemplate_45932df31ffcccae10d4c2396ff08a70ca024e300832e037042d8d7ee89f34c5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/layout/desktop-header.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/layout/desktop-header.html.twig"));

        // line 1
        echo "<header class=\"header-desktop3 d-none d-lg-block\">
    <div class=\"section__content section__content--p35\">
        <div class=\"header3-wrap\">
            <div class=\"header__logo\">
                <a href=\"/user/\">
                    <img src=\"/uploads/site_images/devugo_logo.jpg\" width=\"40\" alt=\"Site logo\" />
                </a>
            </div>
            <div class=\"header__navbar\">
                <ul class=\"list-unstyled\">
                    <li>
                        <a href=\"";
        // line 12
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_exams");
        echo "\">
                            <i class=\"fas fa-book\"></i>
                            <span class=\"bot-line\"></span>Exams</a>
                    </li>
                    <li>
                        <a href=\"";
        // line 17
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_results");
        echo "\">
                            <i class=\"fas fa-trophy\"></i>
                            <span class=\"bot-line\"></span>Results</a>
                    </li>
                </ul>
            </div>
            <div class=\"header__tool\">
                <div class=\"header-button-item has-noti js-item-menu\">
                    <i class=\"zmdi zmdi-notifications\"></i>
                    <div class=\"notifi-dropdown notifi-dropdown--no-bor js-dropdown\">
                        <div class=\"notifi__title\">
                            <p>You have ";
        // line 28
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["no_of_unread"]) || array_key_exists("no_of_unread", $context) ? $context["no_of_unread"] : (function () { throw new RuntimeError('Variable "no_of_unread" does not exist.', 28, $this->source); })())), "html", null, true);
        echo " new Notifications</p>
                        </div>
                        ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notifications"]) || array_key_exists("notifications", $context) ? $context["notifications"] : (function () { throw new RuntimeError('Variable "notifications" does not exist.', 30, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["noti"]) {
            // line 31
            echo "                            <div class=\"notifi__item\">
                                <div class=\"bg-c2 img-cir img-40\">
                                    <i class=\"zmdi zmdi-account-box\"></i>
                                </div>
                                <div class=\"content\">
                                    <p>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["noti"], "title", [], "any", false, false, false, 36), "html", null, true);
            echo "</p>
                                    <span class=\"date\">";
            // line 37
            echo $this->extensions['Knp\Bundle\TimeBundle\Twig\Extension\TimeExtension']->diff(twig_get_attribute($this->env, $this->source, $context["noti"], "createdAt", [], "any", false, false, false, 37));
            echo "</span>
                                </div>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['noti'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                        <div class=\"notifi__footer\">
                            <a href=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_notifications");
        echo "\">All notifications</a>
                        </div>
                    </div>
                </div>
                <div class=\"account-wrap\">
                    <div class=\"account-item account-item--style2 clearfix js-item-menu\">
                        <div class=\"image\">
                            <img src=\"/uploads/user_avatars/";
        // line 49
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 49, $this->source); })()), "user", [], "any", false, false, false, 49), "photo", [], "any", false, false, false, 49), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 49, $this->source); })()), "user", [], "any", false, false, false, 49), "username", [], "any", false, false, false, 49), "html", null, true);
        echo "\" />
                        </div>
                        <div class=\"content\">
                            <a class=\"js-acc-btn\" href=\"#\">";
        // line 52
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 52, $this->source); })()), "user", [], "any", false, false, false, 52), "username", [], "any", false, false, false, 52), "html", null, true);
        echo "</a>
                        </div>
                        <div class=\"account-dropdown js-dropdown\">
                            <div class=\"info clearfix\">
                                <div class=\"image\">
                                    <a href=\"#\">
                                        <img src=\"/uploads/user_avatars/";
        // line 58
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 58, $this->source); })()), "user", [], "any", false, false, false, 58), "photo", [], "any", false, false, false, 58), "html", null, true);
        echo "\" alt=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 58, $this->source); })()), "user", [], "any", false, false, false, 58), "username", [], "any", false, false, false, 58), "html", null, true);
        echo "\" />
                                    </a>
                                </div>
                                <div class=\"content\">
                                    <h5 class=\"name\">
                                        <a href=\"#\">";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 63, $this->source); })()), "user", [], "any", false, false, false, 63), "lastname", [], "any", false, false, false, 63), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 63, $this->source); })()), "user", [], "any", false, false, false, 63), "firstname", [], "any", false, false, false, 63), "html", null, true);
        echo "</a>
                                    </h5>
                                    <span class=\"email\">";
        // line 65
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 65, $this->source); })()), "user", [], "any", false, false, false, 65), "email", [], "any", false, false, false, 65), "html", null, true);
        echo "</span>
                                </div>
                            </div>
                            <div class=\"account-dropdown__body\">
                                <div class=\"account-dropdown__item\">
                                    <a href=\"";
        // line 70
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_account");
        echo "\">
                                        <i class=\"zmdi zmdi-account\"></i>Account</a>
                                </div>
                            </div>
                            <div class=\"account-dropdown__footer\">
                                <a href=\"";
        // line 75
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
        echo "\">
                                    <i class=\"zmdi zmdi-power\"></i>Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/layout/desktop-header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  171 => 75,  163 => 70,  155 => 65,  148 => 63,  138 => 58,  129 => 52,  121 => 49,  111 => 42,  108 => 41,  98 => 37,  94 => 36,  87 => 31,  83 => 30,  78 => 28,  64 => 17,  56 => 12,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header class=\"header-desktop3 d-none d-lg-block\">
    <div class=\"section__content section__content--p35\">
        <div class=\"header3-wrap\">
            <div class=\"header__logo\">
                <a href=\"/user/\">
                    <img src=\"/uploads/site_images/devugo_logo.jpg\" width=\"40\" alt=\"Site logo\" />
                </a>
            </div>
            <div class=\"header__navbar\">
                <ul class=\"list-unstyled\">
                    <li>
                        <a href=\"{{ path('user_exams') }}\">
                            <i class=\"fas fa-book\"></i>
                            <span class=\"bot-line\"></span>Exams</a>
                    </li>
                    <li>
                        <a href=\"{{ path('user_results') }}\">
                            <i class=\"fas fa-trophy\"></i>
                            <span class=\"bot-line\"></span>Results</a>
                    </li>
                </ul>
            </div>
            <div class=\"header__tool\">
                <div class=\"header-button-item has-noti js-item-menu\">
                    <i class=\"zmdi zmdi-notifications\"></i>
                    <div class=\"notifi-dropdown notifi-dropdown--no-bor js-dropdown\">
                        <div class=\"notifi__title\">
                            <p>You have {{ no_of_unread|length }} new Notifications</p>
                        </div>
                        {% for noti in notifications %}
                            <div class=\"notifi__item\">
                                <div class=\"bg-c2 img-cir img-40\">
                                    <i class=\"zmdi zmdi-account-box\"></i>
                                </div>
                                <div class=\"content\">
                                    <p>{{ noti.title }}</p>
                                    <span class=\"date\">{{ noti.createdAt|ago }}</span>
                                </div>
                            </div>
                        {% endfor %}
                        <div class=\"notifi__footer\">
                            <a href=\"{{ path('user_notifications') }}\">All notifications</a>
                        </div>
                    </div>
                </div>
                <div class=\"account-wrap\">
                    <div class=\"account-item account-item--style2 clearfix js-item-menu\">
                        <div class=\"image\">
                            <img src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }}\" />
                        </div>
                        <div class=\"content\">
                            <a class=\"js-acc-btn\" href=\"#\">{{ app.user.username }}</a>
                        </div>
                        <div class=\"account-dropdown js-dropdown\">
                            <div class=\"info clearfix\">
                                <div class=\"image\">
                                    <a href=\"#\">
                                        <img src=\"/uploads/user_avatars/{{ app.user.photo }}\" alt=\"{{ app.user.username }}\" />
                                    </a>
                                </div>
                                <div class=\"content\">
                                    <h5 class=\"name\">
                                        <a href=\"#\">{{ app.user.lastname }} {{ app.user.firstname }}</a>
                                    </h5>
                                    <span class=\"email\">{{ app.user.email }}</span>
                                </div>
                            </div>
                            <div class=\"account-dropdown__body\">
                                <div class=\"account-dropdown__item\">
                                    <a href=\"{{ path('user_account') }}\">
                                        <i class=\"zmdi zmdi-account\"></i>Account</a>
                                </div>
                            </div>
                            <div class=\"account-dropdown__footer\">
                                <a href=\"{{ path('app_logout') }}\">
                                    <i class=\"zmdi zmdi-power\"></i>Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>", "user/layout/desktop-header.html.twig", "C:\\PROJECTS\\personnal\\devugo_cbt_v_1.0.0\\templates\\user\\layout\\desktop-header.html.twig");
    }
}
