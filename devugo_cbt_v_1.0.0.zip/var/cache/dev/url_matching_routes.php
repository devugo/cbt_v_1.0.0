<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/account_type-api/delete' => [[['_route' => 'delete_account_type', '_controller' => 'App\\Controller\\Api\\AccountTypeController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/account_type-api/create' => [[['_route' => 'create_account_type', '_controller' => 'App\\Controller\\Api\\AccountTypeController::create'], null, ['POST' => 0], null, false, false, null]],
        '/exam-api/delete' => [[['_route' => 'delete_exam', '_controller' => 'App\\Controller\\Api\\ExamController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/exam-api/create' => [[['_route' => 'create_exam', '_controller' => 'App\\Controller\\Api\\ExamController::create'], null, ['POST' => 0], null, false, false, null]],
        '/exam-api/add_questions' => [[['_route' => 'add_questions_to_exams', '_controller' => 'App\\Controller\\Api\\ExamController::add_questions'], null, ['POST' => 0], null, false, false, null]],
        '/exam-api/remove_question' => [[['_route' => 'remove_question_from_exam', '_controller' => 'App\\Controller\\Api\\ExamController::remove_question'], null, ['DELETE' => 0], null, false, false, null]],
        '/exam-api/take_exam' => [[['_route' => 'take_exam', '_controller' => 'App\\Controller\\Api\\ExamController::take_exam'], null, ['POST' => 0], null, false, false, null]],
        '/level-api/delete' => [[['_route' => 'delete_level', '_controller' => 'App\\Controller\\Api\\LevelController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/level-api/create' => [[['_route' => 'create_level', '_controller' => 'App\\Controller\\Api\\LevelController::create'], null, ['POST' => 0], null, false, false, null]],
        '/notification-api/delete' => [[['_route' => 'delete_notification', '_controller' => 'App\\Controller\\Api\\NotificationController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/notification-api/create' => [[['_route' => 'create_notification', '_controller' => 'App\\Controller\\Api\\NotificationController::create'], null, ['POST' => 0], null, false, false, null]],
        '/question-api/delete' => [[['_route' => 'delete_question', '_controller' => 'App\\Controller\\Api\\QuestionController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/question-api/create' => [[['_route' => 'create_question', '_controller' => 'App\\Controller\\Api\\QuestionController::create'], null, ['POST' => 0], null, false, false, null]],
        '/subject-api/delete' => [[['_route' => 'delete_subject', '_controller' => 'App\\Controller\\Api\\SubjectController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/subject-api/create' => [[['_route' => 'create_subject', '_controller' => 'App\\Controller\\Api\\SubjectController::create'], null, ['POST' => 0], null, false, false, null]],
        '/user-api/delete' => [[['_route' => 'delete_user', '_controller' => 'App\\Controller\\Api\\UserController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/user-api/create' => [[['_route' => 'create_user', '_controller' => 'App\\Controller\\Api\\UserController::create'], null, ['POST' => 0], null, false, false, null]],
        '/user_group-api/delete' => [[['_route' => 'delete_user_group', '_controller' => 'App\\Controller\\Api\\UserGroupController::delete'], null, ['DELETE' => 0], null, false, false, null]],
        '/user_group-api/create' => [[['_route' => 'create_user_group', '_controller' => 'App\\Controller\\Api\\UserGroupController::create'], null, ['POST' => 0], null, false, false, null]],
        '/admin' => [[['_route' => 'admin_dashboard', '_controller' => 'App\\Controller\\Route\\AdminController::index'], null, null, null, false, false, null]],
        '/admin/users' => [[['_route' => 'admin_users', '_controller' => 'App\\Controller\\Route\\AdminController::users'], null, null, null, false, false, null]],
        '/admin/user-groups' => [[['_route' => 'admin_user_groups', '_controller' => 'App\\Controller\\Route\\AdminController::user_groups'], null, null, null, false, false, null]],
        '/admin/subjects' => [[['_route' => 'admin_subjects', '_controller' => 'App\\Controller\\Route\\AdminController::subjects'], null, null, null, false, false, null]],
        '/admin/questions' => [[['_route' => 'admin_questions', '_controller' => 'App\\Controller\\Route\\AdminController::questions'], null, null, null, false, false, null]],
        '/admin/levels' => [[['_route' => 'admin_levels', '_controller' => 'App\\Controller\\Route\\AdminController::levels'], null, null, null, false, false, null]],
        '/admin/exams' => [[['_route' => 'admin_exams', '_controller' => 'App\\Controller\\Route\\AdminController::exams'], null, null, null, false, false, null]],
        '/admin/account-types' => [[['_route' => 'admin_account_types', '_controller' => 'App\\Controller\\Route\\AdminController::account_types'], null, null, null, false, false, null]],
        '/admin/notifications' => [[['_route' => 'admin_notifications', '_controller' => 'App\\Controller\\Route\\AdminController::notifications'], null, null, null, false, false, null]],
        '/admin/results' => [[['_route' => 'admin_results', '_controller' => 'App\\Controller\\Route\\AdminController::results'], null, null, null, false, false, null]],
        '/admin/profile' => [[['_route' => 'admin_profile', '_controller' => 'App\\Controller\\Route\\AdminController::profile'], null, null, null, false, false, null]],
        '/admin/settings' => [[['_route' => 'admin_settings', '_controller' => 'App\\Controller\\Route\\AdminController::settings'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'login_page', '_controller' => 'App\\Controller\\Route\\SecurityController::login'], null, null, null, false, false, null]],
        '/user' => [[['_route' => 'user_exams', '_controller' => 'App\\Controller\\Route\\UserController::index'], null, null, null, false, false, null]],
        '/user/results' => [[['_route' => 'user_results', '_controller' => 'App\\Controller\\Route\\UserController::results'], null, null, null, false, false, null]],
        '/user/account' => [[['_route' => 'user_account', '_controller' => 'App\\Controller\\Route\\UserController::account'], null, null, null, false, false, null]],
        '/user/notifications' => [[['_route' => 'user_notifications', '_controller' => 'App\\Controller\\Route\\UserController::notifications'], null, null, null, false, false, null]],
        '/user-login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, ['POST' => 0], null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/user-register' => [[['_route' => 'app_register', '_controller' => 'App\\Controller\\SecurityController::register'], null, ['POST' => 0], null, false, false, null]],
        '/test' => [[['_route' => 'app_testing_page', '_controller' => 'App\\Controller\\TestController::test'], null, null, null, false, false, null]],
        '/test-var' => [[['_route' => 'app_testing_var', '_controller' => 'App\\Controller\\TestController::test_var'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/a(?'
                    .'|ccount_type\\-api/update/([^/]++)(*:206)'
                    .'|dmin\\-reset\\-password/([^/]++)(*:244)'
                    .'|pi(?'
                        .'|(?:/(index)(?:\\.([^/]++))?)?(*:285)'
                        .'|/(?'
                            .'|docs(?:\\.([^/]++))?(*:316)'
                            .'|contexts/(.+)(?:\\.([^/]++))?(*:352)'
                            .'|a(?'
                                .'|ccount_types(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:397)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:435)'
                                    .')'
                                .')'
                                .'|pi_audit_trails(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:481)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:519)'
                                    .')'
                                .')'
                            .')'
                            .'|exam(?'
                                .'|s(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:559)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:597)'
                                    .')'
                                .')'
                                .'|_t(?'
                                    .'|akens(?'
                                        .'|(?:\\.([^/]++))?(?'
                                            .'|(*:638)'
                                        .')'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:676)'
                                        .')'
                                    .')'
                                    .'|ypes(?'
                                        .'|(?:\\.([^/]++))?(?'
                                            .'|(*:711)'
                                        .')'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:749)'
                                        .')'
                                    .')'
                                .')'
                            .')'
                            .'|l(?'
                                .'|evels(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:791)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:829)'
                                    .')'
                                .')'
                                .'|gas(?'
                                    .'|(?:\\.([^/]++))?(*:860)'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(*:894)'
                                .')'
                            .')'
                            .'|notifications(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:938)'
                                .')'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:976)'
                                .')'
                            .')'
                            .'|paid_exams(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:1017)'
                                .')'
                                .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                    .'|(*:1056)'
                                .')'
                            .')'
                            .'|question(?'
                                .'|s(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:1100)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:1139)'
                                    .')'
                                .')'
                                .'|_(?'
                                    .'|add_types(?'
                                        .'|(?:\\.([^/]++))?(?'
                                            .'|(*:1184)'
                                        .')'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:1223)'
                                        .')'
                                    .')'
                                    .'|types(?'
                                        .'|(?:\\.([^/]++))?(?'
                                            .'|(*:1260)'
                                        .')'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(*:1296)'
                                    .')'
                                .')'
                            .')'
                            .'|s(?'
                                .'|ettings(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:1340)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:1379)'
                                    .')'
                                .')'
                                .'|tates(?'
                                    .'|(?:\\.([^/]++))?(*:1413)'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(*:1448)'
                                .')'
                                .'|ubjects(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:1486)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:1525)'
                                    .')'
                                .')'
                            .')'
                            .'|user(?'
                                .'|s(?'
                                    .'|(?:\\.([^/]++))?(?'
                                        .'|(*:1566)'
                                    .')'
                                    .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:1605)'
                                    .')'
                                .')'
                                .'|_(?'
                                    .'|exam_questions(?'
                                        .'|(?:\\.([^/]++))?(?'
                                            .'|(*:1655)'
                                        .')'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:1694)'
                                        .')'
                                    .')'
                                    .'|groups(?'
                                        .'|(?:\\.([^/]++))?(?'
                                            .'|(*:1732)'
                                        .')'
                                        .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                            .'|(*:1771)'
                                        .')'
                                    .')'
                                .')'
                            .')'
                        .')'
                    .')'
                .')'
                .'|/exam\\-api/(?'
                    .'|update/([^/]++)(*:1816)'
                    .'|activate/([^/]++)(*:1842)'
                    .'|generate_questions/([^/]++)(*:1878)'
                    .'|submit_(?'
                        .'|answer/([^/]++)(*:1912)'
                        .'|exam/([^/]++)(*:1934)'
                    .')'
                .')'
                .'|/level\\-api/update/([^/]++)(*:1972)'
                .'|/notification\\-api/(?'
                    .'|update/([^/]++)(*:2018)'
                    .'|view/([^/]++)(*:2040)'
                    .'|mark/([^/]++)(*:2062)'
                .')'
                .'|/question\\-api/update/([^/]++)(*:2102)'
                .'|/subject\\-api/(?'
                    .'|update/([^/]++)(*:2143)'
                    .'|activate/([^/]++)(*:2169)'
                .')'
                .'|/user(?'
                    .'|\\-api/(?'
                        .'|update/([^/]++)(*:2211)'
                        .'|activate/([^/]++)(*:2237)'
                    .')'
                    .'|_group\\-api/(?'
                        .'|update/([^/]++)(*:2277)'
                        .'|activate/([^/]++)(*:2303)'
                    .')'
                .')'
                .'|/change\\-password/([^/]++)(*:2340)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        206 => [[['_route' => 'update_account_type', '_controller' => 'App\\Controller\\Api\\AccountTypeController::update'], ['id'], ['PUT' => 0], null, false, true, null]],
        244 => [[['_route' => 'app_admin-reset-password', '_controller' => 'App\\Controller\\SecurityController::admin_password_reset'], ['id'], ['POST' => 0], null, false, true, null]],
        285 => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.action.entrypoint', '_format' => '', '_api_respond' => 'true', 'index' => 'index'], ['index', '_format'], null, null, false, true, null]],
        316 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        352 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        397 => [
            [['_route' => 'api_account_types_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\AccountType', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_account_types_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\AccountType', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        435 => [
            [['_route' => 'api_account_types_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\AccountType', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_account_types_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\AccountType', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_account_types_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\AccountType', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_account_types_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\AccountType', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        481 => [
            [['_route' => 'api_api_audit_trails_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\ApiAuditTrail', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_api_audit_trails_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\ApiAuditTrail', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        519 => [
            [['_route' => 'api_api_audit_trails_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ApiAuditTrail', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_api_audit_trails_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ApiAuditTrail', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_api_audit_trails_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ApiAuditTrail', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_api_audit_trails_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ApiAuditTrail', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        559 => [
            [['_route' => 'api_exams_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Exam', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_exams_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Exam', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        597 => [
            [['_route' => 'api_exams_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Exam', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_exams_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Exam', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_exams_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Exam', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_exams_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Exam', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        638 => [
            [['_route' => 'api_exam_takens_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamTaken', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_exam_takens_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamTaken', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        676 => [
            [['_route' => 'api_exam_takens_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamTaken', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_exam_takens_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamTaken', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_exam_takens_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamTaken', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_exam_takens_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamTaken', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        711 => [
            [['_route' => 'api_exam_types_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamType', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_exam_types_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamType', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        749 => [
            [['_route' => 'api_exam_types_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamType', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_exam_types_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamType', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_exam_types_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamType', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_exam_types_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\ExamType', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        791 => [
            [['_route' => 'api_levels_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Level', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_levels_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Level', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        829 => [
            [['_route' => 'api_levels_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Level', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_levels_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Level', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_levels_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Level', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_levels_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Level', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        860 => [[['_route' => 'api_lgas_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Lga', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null]],
        894 => [[['_route' => 'api_lgas_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Lga', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        938 => [
            [['_route' => 'api_notifications_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Notification', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_notifications_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Notification', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        976 => [
            [['_route' => 'api_notifications_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Notification', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_notifications_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Notification', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_notifications_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Notification', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_notifications_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Notification', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1017 => [
            [['_route' => 'api_paid_exams_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\PaidExam', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_paid_exams_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\PaidExam', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1056 => [
            [['_route' => 'api_paid_exams_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\PaidExam', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_paid_exams_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\PaidExam', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_paid_exams_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\PaidExam', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_paid_exams_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\PaidExam', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1100 => [
            [['_route' => 'api_questions_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Question', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_questions_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Question', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1139 => [
            [['_route' => 'api_questions_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Question', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_questions_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Question', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_questions_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Question', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_questions_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Question', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1184 => [
            [['_route' => 'api_question_add_types_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionAddType', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_question_add_types_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionAddType', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1223 => [
            [['_route' => 'api_question_add_types_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionAddType', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_question_add_types_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionAddType', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_question_add_types_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionAddType', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_question_add_types_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionAddType', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1260 => [
            [['_route' => 'api_question_types_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionType', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_question_types_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionType', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1296 => [[['_route' => 'api_question_types_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\QuestionType', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        1340 => [
            [['_route' => 'api_settings_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_settings_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1379 => [
            [['_route' => 'api_settings_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_settings_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_settings_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_settings_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Setting', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1413 => [[['_route' => 'api_states_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\State', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null]],
        1448 => [[['_route' => 'api_states_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\State', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        1486 => [
            [['_route' => 'api_subjects_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Subject', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_subjects_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\Subject', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1525 => [
            [['_route' => 'api_subjects_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Subject', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_subjects_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Subject', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_subjects_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Subject', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_subjects_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\Subject', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1566 => [
            [['_route' => 'api_users_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_users_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1605 => [
            [['_route' => 'api_users_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_users_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_users_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
            [['_route' => 'api_users_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\User', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        1655 => [
            [['_route' => 'api_user_exam_questions_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserExamQuestions', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_user_exam_questions_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserExamQuestions', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1694 => [
            [['_route' => 'api_user_exam_questions_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserExamQuestions', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_user_exam_questions_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserExamQuestions', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_user_exam_questions_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserExamQuestions', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_user_exam_questions_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserExamQuestions', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1732 => [
            [['_route' => 'api_user_groups_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserGroup', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserGroup', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        1771 => [
            [['_route' => 'api_user_groups_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserGroup', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserGroup', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserGroup', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_user_groups_patch_item', '_controller' => 'api_platform.action.patch_item', '_format' => null, '_api_resource_class' => 'App\\Entity\\UserGroup', '_api_item_operation_name' => 'patch'], ['id', '_format'], ['PATCH' => 0], null, false, true, null],
        ],
        1816 => [[['_route' => 'update_exam', '_controller' => 'App\\Controller\\Api\\ExamController::update'], ['id'], ['PUT' => 0], null, false, true, null]],
        1842 => [[['_route' => 'activate_exam', '_controller' => 'App\\Controller\\Api\\ExamController::activate'], ['id'], ['PUT' => 0], null, false, true, null]],
        1878 => [[['_route' => 'generate_questions_to_exam', '_controller' => 'App\\Controller\\Api\\ExamController::generate_questions'], ['id'], ['POST' => 0], null, false, true, null]],
        1912 => [[['_route' => 'submit_answer', '_controller' => 'App\\Controller\\Api\\ExamController::submit_answer'], ['id'], ['PUT' => 0], null, false, true, null]],
        1934 => [[['_route' => 'submit_exam', '_controller' => 'App\\Controller\\Api\\ExamController::submit_exam'], ['id'], ['PUT' => 0], null, false, true, null]],
        1972 => [[['_route' => 'update_level', '_controller' => 'App\\Controller\\Api\\LevelController::update'], ['id'], ['PUT' => 0], null, false, true, null]],
        2018 => [[['_route' => 'update_notification', '_controller' => 'App\\Controller\\Api\\NotificationController::update'], ['id'], ['PUT' => 0], null, false, true, null]],
        2040 => [[['_route' => 'view_notification', '_controller' => 'App\\Controller\\Api\\NotificationController::view'], ['id'], ['PUT' => 0], null, false, true, null]],
        2062 => [[['_route' => 'mark_notification', '_controller' => 'App\\Controller\\Api\\NotificationController::mark'], ['id'], ['PUT' => 0], null, false, true, null]],
        2102 => [[['_route' => 'update_question', '_controller' => 'App\\Controller\\Api\\QuestionController::update'], ['id'], ['POST' => 0], null, false, true, null]],
        2143 => [[['_route' => 'update_subject', '_controller' => 'App\\Controller\\Api\\SubjectController::update'], ['id'], ['PUT' => 0], null, false, true, null]],
        2169 => [[['_route' => 'activate_subject', '_controller' => 'App\\Controller\\Api\\SubjectController::activate'], ['id'], ['PUT' => 0], null, false, true, null]],
        2211 => [[['_route' => 'update_user', '_controller' => 'App\\Controller\\Api\\UserController::update'], ['id'], ['POST' => 0], null, false, true, null]],
        2237 => [[['_route' => 'activate_user', '_controller' => 'App\\Controller\\Api\\UserController::activate'], ['id'], ['PUT' => 0], null, false, true, null]],
        2277 => [[['_route' => 'update_user_group', '_controller' => 'App\\Controller\\Api\\UserGroupController::update'], ['id'], ['PUT' => 0], null, false, true, null]],
        2303 => [[['_route' => 'activate_user_group', '_controller' => 'App\\Controller\\Api\\UserGroupController::activate'], ['id'], ['PUT' => 0], null, false, true, null]],
        2340 => [
            [['_route' => 'app_change-password', '_controller' => 'App\\Controller\\SecurityController::change_password'], ['id'], ['POST' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
