<?php

namespace App\Controller;

use App\Entity\Exam;
use App\Entity\AccountType;
use App\Repository\ExamRepository;
use App\Repository\UserRepository;
use App\Repository\LevelRepository;
use App\Repository\SubjectRepository;
use App\Repository\QuestionRepository;
use App\Repository\ExamTakenRepository;
use Doctrine\ORM\EntityManagerInterface;
use App\Repository\AccountTypeRepository;
use App\Repository\NotificationRepository;
use Symfony\Component\Security\Core\Security;
use ApiPlatform\Core\Api\IriConverterInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;


class TestController extends AbstractController
{
    /**
     * @Route("/test", name="app_testing_page")
     */
    public function test(UserRepository $userRepository, Security $security, NotificationRepository $notificationRepository, EntityManagerInterface $entityManager, ExamTakenRepository $examTakenRepository, SubjectRepository $subjectRepository, ExamRepository $examRepository, LevelRepository $levelRepository, QuestionRepository $questionRepository, IriConverterInterface $iriConverter, SerializerInterface $serializer, AccountTypeRepository $accRepo)
    {
        dd(count($security->getUser()->getRoles()));
        // $user = $userRepository->find(14);
        // // dd($user);

        // dd($user->getExamTakens());
        // $examTaken = $examTakenRepository->find(4);
        // // dd($examTaken);
        // $questions = $examTaken->getUserExamQuestion();
        // // $questions = $examRepository->find(9)->getQuestions();
        // // dd($questions);
        // $newQuestions = array();
        // foreach($questions as $question){
        //     \array_push($newQuestions, $question);
        // };
        // dd($newQuestions);
        // $subject = $subjectRepository->find(1);
        // $level = $levelRepository->find(1);

        // $exam = $examRepository->find(11);
        
        // $existing_questions = $exam->getQuestions();

        // dd($existing_questions);

        // $questions = $questionRepository->findBy(['subject' => $subject, 'level' => $level]);
        // shuffle($questions);

        // dd($questions);
    }

    /**
     * @Route("/test-var", name="app_testing_var")
     */
    public function test_var()
    {
        $arr = array("read" => true, "create" => false);
        $ugo = 'read';
        dd($arr[$ugo]);
    }
}